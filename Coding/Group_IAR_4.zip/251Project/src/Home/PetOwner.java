package Home;

import java.util.ArrayList;
import java.util.Scanner;

public class PetOwner extends Account {

    private ArrayList<DonateSupply> donatedSupplies = new ArrayList();
    ArrayList<RequestSupplyDonation> supplyRequests = new ArrayList();
    ArrayList<Pet> animalOffers = new ArrayList();

    //constructor
    public PetOwner(String username, String password, String name, String phoneNumber) {
        super(username, password, name, phoneNumber);
    }

    //Setters & Getters

    public ArrayList<Pet> getPetOffers() {
        return animalOffers;
    }

    public void setPetOffers(ArrayList<Pet> animalOffers) {
        this.animalOffers = animalOffers;
    }
  

    public ArrayList<DonateSupply> getDonatedSupplies() {
        return donatedSupplies;
    }

    public void setDonatedSupplies(ArrayList<DonateSupply> donatedSupplies) {
        this.donatedSupplies = donatedSupplies;
    }

    public ArrayList<RequestSupplyDonation> getSupplyRequests() {
        return supplyRequests;
    }

    public void setSupplyRequests(ArrayList<RequestSupplyDonation> supplyRequests) {
        this.supplyRequests = supplyRequests;
    }

    ////////// methods /////////
    public void requestSuppliesDonation() {
        RequestSupplyDonation a = new RequestSupplyDonation(this);
        supplyRequests.add(a);
        Home.donationSupplyRequets.put(this.getUsername(), this);
        System.out.print(" \nDear, " + this.getName()
                + "\n Your donation request has been submitted successfully\n"
                + "\n----------------------------------");

    }

    // offer adoption ................................................................
    public void offerAdoption(Scanner s) {
        Pet a = new Pet();
        a.petOfferForm(this);
        animalOffers.add(a);
        Home.petOffers.put(this.getUsername(), this);
        System.out.print(" \nDear, " + this.getName()
                + "\n               Your Offer has been submitted successfully\n   take care of your pet until someone can take care of it "
                + "\n----------------------------------\n");

    }

    public void addDonatedSupplies(DonateSupply supply) {
        donatedSupplies.add(supply);
    }

    public String getDonationRequestInfo(int index) {
        return supplyRequests.get(index).retrieveRequest();
    }

    public void acquireSupply() {
        if (donatedSupplies.isEmpty()) {
            System.out.println("\n---------- There are no donations ----------\n");
        }
        for (int i = 0; i < donatedSupplies.size(); i++) {
            System.out.println("");
            System.out.println(donatedSupplies.get(i).toString());
            System.out.println("");
        }

    }

    @Override
    public String toString() {
        return ("Name : " + super.getName() + "\nphoneNumber : " + super.getPhoneNumber());
    }

}
