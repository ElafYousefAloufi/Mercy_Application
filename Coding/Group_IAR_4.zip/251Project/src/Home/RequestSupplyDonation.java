
package Home;

import java.util.Scanner;

public class RequestSupplyDonation {

    String type;
    PetOwner petOwnerId;
    String description;
    
    public RequestSupplyDonation() {
        
    }
    
    public RequestSupplyDonation(PetOwner username) {
        this.petOwnerId = username;
        Scanner s = new Scanner(System.in);
        System.out.println("\n--------Request Donation Form--------\n");
        System.out.print("Enter Your Supply Type: ");
        this.type = s.nextLine().trim();
        System.out.print("Write a Description: ");
        this.description  = s.nextLine().trim();
       
    }
    
    public void iniSupplyInfo(String des,String type, PetOwner username){
        this.description = des;
        this.type = type;
        this.petOwnerId = username;
        petOwnerId.getSupplyRequests().add(this);
        Home.donationSupplyRequets.put(petOwnerId.getUsername(), petOwnerId);
    }
    
      public String retrieveRequest() {
                return " Pet Owner Name: " + petOwnerId.getName()
                    + "\n Description of request: "
                    + "\n " + this.getDescription()
                    + "\n Supply Type: " + this.getType();
    }

     

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

}
