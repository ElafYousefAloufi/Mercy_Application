package Home;

public class DonateSupply {

    private String Supply_type;
    private String Supply_name;
    private String brief_description;
    private String email;
    private String phone;
    private String customer_Username;
    private String petOwner_Username;

    public DonateSupply() {

    }

    @Override
    public String toString() {
        return "===============================\n"
                +"From Customer: "+customer_Username+
                "\nCustomer contact information:"+
                "\nEmail: "+ email+"    Phone Number: "+phone+
                "\nSupply Name: "+Supply_name+
                "\nSupply Type: "+ Supply_type+
                "\nDescription: "+ brief_description;
    }

    public String getSupply_type() {
        return Supply_type;
    }

    public String getSupply_name() {
        return Supply_name;
    }

    public String getBrief_description() {
        return brief_description;
    }

   

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public void setSupply_type(String Supply_type) {
        this.Supply_type = Supply_type;
    }

    public void setSupply_name(String Supply_name) {
        this.Supply_name = Supply_name;
    }

    public void setBrief_description(String brief_description) {
        this.brief_description = brief_description;
    }

    

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public DonateSupply(String Supply_type, String Supply_name, String brief_description, String email, String phone, String customer, String petonwer) {
        this.Supply_type = Supply_type;
        this.Supply_name = Supply_name;
        this.brief_description = brief_description;
        this.email = email;
        this.phone = phone;
        this.customer_Username = customer;
        this.petOwner_Username = petonwer;
    }
}
