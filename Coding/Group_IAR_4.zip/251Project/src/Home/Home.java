package Home;

import java.util.*;
import java.util.Map;

public class Home {

    public static Map<String, PetOwner> donationSupplyRequets = new HashMap<String, PetOwner>();
    public static Map<String, PetOwner> petOffers = new HashMap<String, PetOwner>();
    public static HashMap<String, PetOwner> PetOwners = new HashMap<String, PetOwner>(); //contains all petowner acoounts
    public static Map<String, Customer> Customers = new HashMap<String, Customer>(); //contains all customer acoounts

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        //Initialize system data + initialize users
        createPetOwnerUsers();
        createCustomerUsers();
        initializeDonationRequestInfo();
        initializeanimalOffersInfo();
        //////////////////////////////////////////////
        
        String command = "";
        while (true) {
            boolean isLoging = false;
            do {
                System.out.println("\n-- you have to log in to use any feature in the system --");
                System.out.println("  \n------------------------ Log in --------------------------\n");
                Customer customer;
                PetOwner petowner;
                System.out.print("Your Username : ");
                String username = s.nextLine();
                System.out.print("Your password : ");
                String password = s.nextLine();
                //check if the input info is correct for the account and exist in the system as pet owner 
                if (PetOwners.containsKey(username) && PetOwners.get(username).getPassword().equalsIgnoreCase(password)) {
                    petowner = PetOwners.get(username);
                    isLoging = true;
                    System.out.println("\n--------------------- Successfully log in -------------------\n");
                    do {
                        System.out.println("\n.....................Welcome Pet owner.....................\n");
                        System.out.println("1. Request supply donation\n2. Offer adoption\n3. Acquire Supply\n4. log out\n");
                        System.out.print("Choose a function : ");
                        command = s.nextLine().trim();
                        switch (command) {
                            case "1":
                                petowner.requestSuppliesDonation();
                                break;
                            case "2":
                                petowner.offerAdoption(s);
                                break;
                            case "3":
                                petowner.acquireSupply();
                                break;

                        }
                    } while (!command.equalsIgnoreCase("4"));
                    System.out.println("\n\n  ... Thank you for using our app ... \n  ");
                    break;
                }
                //check if the input info is correct for the account and exist in the system as customer
                if (Customers.containsKey(username) && Customers.get(username).getPassword().equalsIgnoreCase(password)) {
                    customer = Customers.get(username);
                    isLoging = true;
                    System.out.println("\n.......... Successfully log in .............\n");
                    do {
                        System.out.println("\n.....................Welcome customer.....................\n");
                        System.out.println("1. donate\n2. adopt\n3. log out\n");
                        System.out.print("Choose a function : ");
                        command = s.nextLine().trim();
                        switch (command) {
                            case "1":
                                customer.displaySupplyDonationRequests(s);
                                break;
                            case "2":
                                customer.Adopt(s);
                                break;
                        }
                    } while (!command.equalsIgnoreCase("3"));
                    System.out.println("\n\n  ... Thank you for using our app ... \n  ");
                } else {
                    System.out.println("\n.... Wrong password or username!!!  try again ....\n");
                }

            } while (isLoging == false);
        }

    }


    //------------------------------------------initialization--------------------------------------------------------
    static void createPetOwnerUsers() {
        //accounts in application
        PetOwners.put("ElafAloufi", new PetOwner("ElafAloufi", "1234", "Elaf", "0504545454"));
        PetOwners.put("manar123", new PetOwner("manar123", "a112233", "Manar", "05059999904"));
        PetOwners.put("Shatha12", new PetOwner("Shatha12", "1234", "Shatha", "0504545456"));
        PetOwners.put("Reema10", new PetOwner("Reema10", "1234", "Reema", "0504545456"));
    }

    static void createCustomerUsers() {
        Customers.put("JeeOt", new Customer("JeeOt", "1234", "Jeelan", "0504545458"));

    }

    static void initializeDonationRequestInfo() {
        new RequestSupplyDonation().iniSupplyInfo("I need dog for my 5 month old dog", "Food", PetOwners.get("manar123"));
        new RequestSupplyDonation().iniSupplyInfo("I need cat toys, any toy would be helpful", "Toy", PetOwners.get("Shatha12"));
    }

    static void initializeanimalOffersInfo() {
        new Pet().inianimalInfo("Tera", "cat", "female", 3, "3 months cat with white fur, green eyes and black birthmark on her back", PetOwners.get("Reema10"));
        new Pet().inianimalInfo("BulBul", "bird", "male", 6, "6 months bird with colorful fur and loud voice", PetOwners.get("ElafAloufi"));
    }
}
