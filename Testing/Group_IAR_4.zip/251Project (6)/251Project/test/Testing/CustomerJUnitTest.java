package Testing;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Home.DonateSupply;
import Home.Home;
import static Home.Home.PetOwners;
import Home.PetOwner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class CustomerJUnitTest {

    public CustomerJUnitTest() {
    }

    @Test
    public void AdoptTest() {
        ArrayList<String> petOwnersId = new ArrayList();
        for (Map.Entry<String, PetOwner> set : Home.petOffers.entrySet()) {
            String key = "1";
            petOwnersId.add(Home.PetOwners.get(key).getUsername());
            assertTrue(petOwnersId.contains(key));
        }
    }

    @Test
    public void displaySupplyDonationRequestsTest() {
        ArrayList<String> petOwnersId = new ArrayList();
        for (Map.Entry<String, PetOwner> set : Home.petOffers.entrySet()) {
            assertTrue(petOwnersId.add(Home.PetOwners.get("1").getUsername()));
        }
    }

    @Test
    public void DonateSupplyTest() {
        DonateSupply e = new DonateSupply("Toy", "Ball", "Blue", "AL@gmail.com", "0509412382", "All", "own");
        HashMap<String, PetOwner> PetOwners = new HashMap<>();
        PetOwners.put("own", new PetOwner("own", "1234", "Elaf", "0504545454"));
        PetOwners.get("own").addDonatedSupplies(e);
        assertTrue(PetOwners.containsKey("own"));

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

  
}