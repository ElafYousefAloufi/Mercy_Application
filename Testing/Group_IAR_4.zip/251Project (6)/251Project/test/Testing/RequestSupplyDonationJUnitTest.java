/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Testing;

import Home.PetOwner;
import Home.RequestSupplyDonation;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class RequestSupplyDonationJUnitTest {
    
    @Test
    public void iniSupplyInfoTest() {
        PetOwner petOwner = new PetOwner("testName", "1233456", "TEST", "0509274243");
        RequestSupplyDonation requestSupplyDonation = new RequestSupplyDonation();
        requestSupplyDonation.iniSupplyInfo("testDesc", "Food", petOwner);
        assertEquals(requestSupplyDonation, petOwner.getSupplyRequests().get(0));
        assertNotNull(Home.Home.donationSupplyRequets.get(petOwner.getUsername()));
        assertEquals(petOwner, Home.Home.donationSupplyRequets.get(petOwner.getUsername()));
    }

    @Test
    public void retrieveRequestTest() {
        PetOwner petOwner = new PetOwner("testName", "1233456", "TEST", "0509274243");
        RequestSupplyDonation requestSupplyDonation = new RequestSupplyDonation();
        requestSupplyDonation.iniSupplyInfo("testDesc", "Food", petOwner);
        String actual = requestSupplyDonation.retrieveRequest();
        String expected = " Pet Owner Name: TEST\n" +
                " Description of request: \n" +
                " testDesc\n" +
                " Supply Type: Food";
        assertEquals(expected, actual);
    }

    @Test
    public void getTypeTest() {
        PetOwner petOwner = new PetOwner("testName", "1233456", "TEST", "0509274243");
        RequestSupplyDonation requestSupplyDonation = new RequestSupplyDonation();
        requestSupplyDonation.iniSupplyInfo("testDesc", "Food", petOwner);
        String actual = requestSupplyDonation.getType();
        String expected = "Food";
        assertEquals(expected, actual);
    }

    @Test
    public void getDescriptionTest() {
        PetOwner petOwner = new PetOwner("testName", "1233456", "TEST", "0509274243");
        RequestSupplyDonation requestSupplyDonation = new RequestSupplyDonation();
        requestSupplyDonation.iniSupplyInfo("testDesc", "Food", petOwner);
        String actual = requestSupplyDonation.getDescription();
        String expected = "testDesc";
        assertEquals(expected, actual);
    }

    public RequestSupplyDonationJUnitTest() {

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}


}
