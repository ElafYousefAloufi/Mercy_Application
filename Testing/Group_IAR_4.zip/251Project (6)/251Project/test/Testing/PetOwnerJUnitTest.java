/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Testing;

import Home.DonateSupply;
import Home.Pet;
import Home.PetOwner;
import Home.RequestSupplyDonation;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class PetOwnerJUnitTest {

    public PetOwnerJUnitTest() {
    }

    @Test
    public void reqSupplyDonationTest() {
        ArrayList<RequestSupplyDonation> supplyRequests = new ArrayList();
        RequestSupplyDonation a = new RequestSupplyDonation();
        assertTrue(supplyRequests.add(a));

    }

    @Test
    public void offerAdoptionTest() {
        PetOwner owner = new PetOwner("Elaf", "1233456", "Yousef", "0509274243");
        Pet a = new Pet();
        a.iniPetInfo("Lucy", "Cat", "Female", 2, "White", owner);
        ArrayList<Pet> animalOffers = new ArrayList();
        animalOffers.add(a);
        assertTrue(animalOffers.contains(a));

    }

    @Test
    public void addDonatedSuppliesTest() {
        DonateSupply e = new DonateSupply("Toy", "Ball", "Blue", "AL@gmail.com", "0509412382", "All", "Elaf");
        ArrayList<DonateSupply> donatedSupplies = new ArrayList();
        donatedSupplies.add(e);
        assertTrue(donatedSupplies.contains(e));
    }

    @Test
    public void acquireSupplyTest() {
        ArrayList<DonateSupply> donatedSupplies = new ArrayList();
        DonateSupply e = new DonateSupply("Toy", "Ball", "Blue", "AL@gmail.com", "0509412382", "All", "Elaf");
        donatedSupplies.add(e);
        if (!donatedSupplies.isEmpty()) {
            assertFalse(donatedSupplies.isEmpty());
        } else {
            assertTrue(donatedSupplies.contains(e));
        }

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
