package Home;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class Customer extends Account {


    public Customer(String username, String password, String name, String phoneNumber) {
        super(username, password, name, phoneNumber);
    }

    public Customer(String username, String password) {
        super(username, password);
    }


    public void Adopt(Scanner s) {
        ArrayList<String> petOwnersId = new ArrayList();
        int i = 1; 
        //technique to iterate through Hashmap 
        for (Map.Entry<String, PetOwner> set : Home.petOffers.entrySet()) {
             String key = set.getKey();
            petOwnersId.add(Home.PetOwners.get(key).getUsername());
            for (int k = 0; k < Home.PetOwners.get(key).getPetOffers().size(); k++) {
                System.out.println("==================================");
                System.out.println(i + ".");
                System.out.println(Home.PetOwners.get(key).getPetOffers().get(k).retrieveOffer());
                i++;
            }
            System.out.println();
        }
        System.out.print("Type (quit) to exit: ");
        s.nextLine().toLowerCase().trim();
    }

    public void displaySupplyDonationRequests(Scanner s) {
        System.out.println("\n---------------Donation Requests---------------");
        System.out.println("        ....The Best way to help a pet....          ");
        this.donate();
        switch (s.next().trim()) {
            case "1":
                break;
            case "2":
                ArrayList<String> petOwnersId = new ArrayList();
                int i = 1; 
                //technique to iterate through Hashmap 
                for (Map.Entry<String, PetOwner> set : Home.donationSupplyRequets.entrySet()) {
                    String key = set.getKey();
                    petOwnersId.add(Home.PetOwners.get(key).getUsername());
                    for (int k = 0; k < Home.PetOwners.get(key).getSupplyRequests().size(); k++) {
                        System.out.println("==================================");
                        System.out.println(i + ".");
                        System.out.println(Home.PetOwners.get(key).getSupplyRequests().get(k).retrieveRequest());
                        i++;
                    }
                    System.out.println();

                }
                s.nextLine();
                System.out.print("Type (quit) to exit or choose a number of the pet owner to donate: ");
                String command = s.nextLine().toLowerCase().trim();
                if (!command.equalsIgnoreCase("quit") && !command.equalsIgnoreCase("quite") && !command.equalsIgnoreCase("q")) {
                    int arrayIndex = Integer.parseInt(command) - 1;
                    this.DonateSupply(Home.PetOwners.get(petOwnersId.get(arrayIndex)).getUsername());
                }
        }

    }

    public void donate() {

        System.out.println("\nChoose Donation Type:\n ");
        System.out.println("1. Display Money Donation Requests(not Available)");
        System.out.println("2. Display Donate Supply Donation Requests");
        System.out.print("\nEnter your choice: ");

    }

    public void DonateSupply(String petownerUsername) {
        Scanner input = new Scanner(System.in);
        System.out.println("\n---------------Donate Supply Form---------------\n");
        System.out.println("Please Fill supply information\n ");

        System.out.print("Enter supply type: ");
        String Supply_type = input.next();

        input.nextLine();

        System.out.print("Enter supply name: ");
        String Supply_name = input.nextLine();

        System.out.print("Enter supply descrption: ");
        String brief_description = input.nextLine();

        System.out.print("Enter your Email: ");
        setEmail(input.next());

        System.out.print("Enter your Phone Number: ");
        setPhoneNumber(input.next());

        System.out.println("");

        //Create Supply Object
        DonateSupply CustomerSupply = new DonateSupply(Supply_type, Supply_name, brief_description, getEmail(), getPhoneNumber(), this.getUsername(), petownerUsername);
        //Send Supply object to petOwners's supplyList

        Home.PetOwners.get(petownerUsername).addDonatedSupplies(CustomerSupply);

        System.out.println("Dear, Customer " + getName()
                + "\n Thank You for your donation \n"
                + " Your donation submitted successfully\n");
    }

}
