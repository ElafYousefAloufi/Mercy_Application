/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Home;

import java.io.File;
import java.util.Scanner;

public class Pet {

    String name;
    int age;
    String type;
    String sex;
    File medicalState;
    PetOwner petOwnerId;
    String description;

    public Pet() {

    }


    public void iniPetInfo(String name, String type, String sex, int age, String desc, PetOwner username) {
        this.petOwnerId = username;
        this.name = name;
        this.type = type;
        this.sex = sex;
        this.age = age;
        this.description = desc;
        petOwnerId.getPetOffers().add(this);
        Home.petOffers.put(petOwnerId.getUsername(), petOwnerId);
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getType() {
        return type;
    }

    public String getSex() {
        return sex;
    }

    public File getMedicalState() {
        return medicalState;
    }

    

    public PetOwner getPetOwnerId() {
        return petOwnerId;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setMedicalState(File medicalState) {
        this.medicalState = medicalState;
    }

    

    public void setPetOwnerId(PetOwner petOwnerId) {
        this.petOwnerId = petOwnerId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String retrieveOffer() {
        return " Pet Owner Name: " + petOwnerId.getName()
                + "\n Animal name: " + this.getName()
                + "\n Aniaml age: " + this.getAge()
                + "\n Aniaml sex: " + this.getSex()
                + "\n Supply Type: " + this.getType()
                + "\n Description of the pet: "
                + "\n " + this.getDescription();

    }

    public void petOfferForm(PetOwner username) {
        this.petOwnerId = username;
        Scanner s = new Scanner(System.in);
        Scanner scan = new Scanner(System.in);
        System.out.println("\n--------Offer Adoptaion Form--------\n");
        System.out.print("Enter Your pet name: ");
        this.name = s.nextLine().trim();
        System.out.print("Enter Your pet type: ");
        this.type = s.nextLine().trim();
        System.out.print("Enter Your pet sex: ");
        this.sex = s.nextLine().trim();
        System.out.print("Enter Your pet age: ");
        this.age = s.nextInt();
        System.out.print("Enter description for more deatils about your pet: ");
        this.description = scan.nextLine();
        System.out.println();
    }

}
